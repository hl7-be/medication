# Home - Medication v1.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/ImplementationGuide/hl7.fhir.be.medication | *Version*:1.1.0 |
| Draft as of 2020-02-26 | *Computable Name*:Medication |

 This is the HL7 Belgium FHIR Implementation Guide for the Medication workgroup. 

 

### Content

This publication contains the specifications related to the medication areas and is structured in the following content sections:

**Background:** Information about the specifications, or what you should know to be able to best navigate and use these specifications. Contains a general introduction to the publication structure and content, the artefact types, common privacy and security specifications and the official HL7 FHIR release that this specification is based upon.

**Functional Description:** Functional content, more relevant for business or functional analysts, as well as health professionals. Contains the context around these specifications (relevant projects, legal and implementation aspects), the interoperability actors and transactions, and especially the use cases that have been considered in the specification and the logical data models – the functional (i.e. non-technical) data sets that are used in data exchange.

**Detailed Specifications:** The actual technical specifications – the FHIR conformance resources that are defined in this specification – profiles, data types, capability statements. This is targeted at (technical) implementers.

**Terminology:** The vocabulary resources – Naming Systems, Code Systems and Value Sets, which support semantic interoperability. These resources define the use of standard terminologies (e.g. LOINC, SNOMED-CT) or internal codes for Belgium, e.g. official codes for Civil Status).

### Navigation

This implementation guide uses the FHIR web-based publication. This allows easy navigation between the Belgium-specific portion of the implementation guide and the resources, data types, value sets and other specification components leveraged from the FHIR core specification. This approach also allows implementers to easily navigate to the information needed to perform a task.

The top menu allows quick navigation to the different sections, and a [Table of Contents](toc.md)  is provided with the entire content of this Implementation Guide. (Be aware that some pages have multiple tabs).

### Intellectual Property Considerations

 While this implementation guide and the underlying FHIR are licensed as public domain, this guide includes examples making use of terminologies such as LOINC, SNOMED CT and others which have more restrictive licensing requirements. Implementers should make themselves familiar with licensing and any other constraints of terminologies, questionnaires, and other components used as part of their implementation process. In some cases, licensing requirements may limit the systems that data captured using certain questionnaires may be shared with. 

This publication includes IP covered under the following statements.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.0.2/CodeSystem-ISO3166Part1.html): [AD](StructureDefinition-AD.md), [ANY](StructureDefinition-ANY.md)... Show 35 more, [BELMMedProduct](StructureDefinition-BELMMedProduct.md), [BEMedicationLine](StructureDefinition-be-medicationline.md), [BEMedicationType](CodeSystem-medication-type.md), [BEMedicationTypeVS](ValueSet-medication-type-vs.md), [BEModelMedicationDispense](StructureDefinition-be-model-medicationdispense.md), [BL](StructureDefinition-BL.md), [BeExtDispenseRequestNeededCategory](StructureDefinition-BeExtDispenseRequestNeededCategory.md), [BeExtDosageOverride](StructureDefinition-BeExtDosageOverride.md), [BeExtDosageOverrideReason](StructureDefinition-BeExtDosageOverrideReason.md), [BeExtExposureCategory](StructureDefinition-BeExtExposureCategory.md), [BeExtMedicationType](StructureDefinition-BeExtMedicationType.md), [BeMedicationDispense](StructureDefinition-be-medicationdispense.md), [BeNSCNK](NamingSystem-be-ns-cnk-codes.md), [BeNSCTIExtended](NamingSystem-be-ns-cti-extended-code.md), [BeNSPrescriptions](NamingSystem-be-ns-prescription-ids.md), [BeNSProductPackage](NamingSystem-be-ns-product-package-type.md), [CD](StructureDefinition-CD.md), [Class](StructureDefinition-Class.md), [DT](StructureDefinition-DT.md), [DispenserTypes](ValueSet-be-vs-dispenser-types.md), [EN](StructureDefinition-EN.md), [II](StructureDefinition-II.md), [INT](StructureDefinition-INT.md), [KMEHRMS](StructureDefinition-KMEHRMS.md), [Medication](index.md), [MedicationExposureCategoryVS](ValueSet-medication-exposure-category-vs.md), [MedicationLine](StructureDefinition-be-model-medicationline.md), [MedicationLineOrigintype](CodeSystem-medication-line-origin-type.md), [MedicationLineOrigintypeVS](ValueSet-medication-line-origin-type-vs.md), [PQ](StructureDefinition-PQ.md), [REAL](StructureDefinition-REAL.md), [RTO](StructureDefinition-RTO.md), [ST](StructureDefinition-ST.md), [TS](StructureDefinition-TS.md) and [Untyped](StructureDefinition-Untyped.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.0.2/CodeSystem-v3-ucum.html): [MedicationDispense/example-dispense-hospital](MedicationDispense-example-dispense-hospital.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [BeExtExposureCategory](StructureDefinition-BeExtExposureCategory.md), [BeMedicationDispense](StructureDefinition-be-medicationdispense.md), [MedicationExposureCategoryVS](ValueSet-medication-exposure-category-vs.md) and [MedicationLine](StructureDefinition-be-model-medicationline.md)


