# Belgian Medication Record overview - Medication v1.1.0

* [**Table of Contents**](toc.md)
* **Belgian Medication Record overview**

## Belgian Medication Record overview

The Belgian Medication Record is the evolution of the Medication Schema.

It covers the functionality of the Medication Schema and enables the evolution towards a more detailed and comprehensive overview of a patient’s medication, when adequate.

-------

