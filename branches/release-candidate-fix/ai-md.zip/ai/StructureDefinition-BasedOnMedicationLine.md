# BasedOnMedicationLine - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BasedOnMedicationLine**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BasedOnMedicationLine-definitions.md) 
*  [Mappings](StructureDefinition-BasedOnMedicationLine-mappings.md) 
*  [XML](StructureDefinition-BasedOnMedicationLine.profile.xml.md) 
*  [JSON](StructureDefinition-BasedOnMedicationLine.profile.json.md) 
*  [TTL](StructureDefinition-BasedOnMedicationLine.profile.ttl.md) 

## Extension: BasedOnMedicationLine 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BasedOnMedicationLine | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BasedOnMedicationLine |

Based on medication line.

**Context of Use**

This extension may be used on the following element(s):

* Element ID MedicationRequest
* Element ID MedicationDispense

**Usage info**

**Usages:**

* Use this Extension: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md) and [BeMedicationPrescription](StructureDefinition-BeMedicationPrescription.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BasedOnMedicationLine)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Reference: Based on medication line.

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Summary**

Simple Extension with the type Reference: Based on medication line.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-BasedOnMedicationLine.csv), [Excel](StructureDefinition-BasedOnMedicationLine.xlsx), [Schematron](StructureDefinition-BasedOnMedicationLine.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeDosage.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BasedOnMedicationLine-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

