#  - Medication v1.1.0

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](NamingSystem-be-ns-cti-extended-code.md) 
*  [XML](NamingSystem-be-ns-cti-extended-code.xml.md) 
*  [JSON](NamingSystem-be-ns-cti-extended-code.json.md) 
*  [TTL](NamingSystem-be-ns-cti-extended-code.ttl.md) 

## : BeNSCTIExtended - Change History

History of changes for be-ns-cti-extended-code .

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

