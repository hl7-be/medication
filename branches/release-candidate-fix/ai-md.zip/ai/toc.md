# Table of Contents - Medication v1.1.0

* **Table of Contents**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

## Table of Contents

| |
| :--- |
| [0 Table of Contents](toc.md) |
| [1 Home](index.md) |
| [2 Belgian Medication Record overview](medicationrecord.md) |
| [3 Definitions](definitions.md) |
| [4 Medication Record - Use cases](usecases-medicationrecord.md) |
| [5 Medication Record - Extended scenarios](medicationrecord-scenarios.md) |
| [6 Dispense - Use cases](usecases-dispense.md) |
| [7 How to read this specification](howto.md) |
| [8 Downloads](downloads.md) |
| [9 Artifacts Summary](artifacts.md) |
| [9.1 Dosaging (model)](StructureDefinition-BeModelDosagingInformation.md) |
| [9.2 Medication (model)](StructureDefinition-BeModelMedication.md) |
| [9.3 Medication Dispense (model)](StructureDefinition-BeModelMedicationDispense.md) |
| [9.4 Medication Line (model)](StructureDefinition-BeModelMedicationLine.md) |
| [9.5 Medication prescription (model)](StructureDefinition-BeModelMedicationPrescription.md) |
| [9.6 BeMedicationDispense](StructureDefinition-BeMedicationDispense.md) |
| [9.7 BeMedicationLine](StructureDefinition-BeMedicationLine.md) |
| [9.8 BeMedicationPrescription](StructureDefinition-BeMedicationPrescription.md) |
| [9.9 Medication Dosage](StructureDefinition-BeDosage.md) |
| [9.10 BasedOnMedicationLine](StructureDefinition-BasedOnMedicationLine.md) |
| [9.11 BeExtAdherenceStatus](StructureDefinition-BeExtAdherenceStatus.md) |
| [9.12 BeExtInstructionsForReimbursement](StructureDefinition-BeExtInstructionsForReimbursement.md) |
| [9.13 BeExtMedicationType](StructureDefinition-BeExtMedicationType.md) |
| [9.14 BeExtRecordedDate](StructureDefinition-BeExtRecordedDate.md) |
| [9.15 BeExtRecorder](StructureDefinition-BeExtRecorder.md) |
| [9.16 BeMedicationExposureCategory](StructureDefinition-BeMedicationExposureCategory.md) |
| [9.17 Medication Line Registration Status](StructureDefinition-BeExtMedicationLineRegistrationStatus.md) |
| [9.18 MedicationRequest - Off-label use](StructureDefinition-BeExtOffLabel.md) |
| [9.19 Adherence Status Reason](CodeSystem-BeMedicationLineAdherenceStatusReason.md) |
| [9.20 Adherence Status Reason ValueSet](ValueSet-BeMedicationLineAdherenceStatusReasonVS.md) |
| [9.21 be-ns-cnk-codes](NamingSystem-be-ns-cnk-codes.md) |
| [9.22 be-ns-cti-extended-code](NamingSystem-be-ns-cti-extended-code.md) |
| [9.23 be-ns-prescription-ids](NamingSystem-be-ns-prescription-ids.md) |
| [9.24 be-ns-product-package-type](NamingSystem-be-ns-product-package-type.md) |
| [9.25 BeExtAdherenceStatus](ValueSet-BeMedicationLineAdherenceStatusVS.md) |
| [9.26 Dispenser Types](ValueSet-be-vs-dispenser-types.md) |
| [9.27 Medication exposure intent](ValueSet-BeMedicationExposureIntentVS.md) |
| [9.28 Medication Line Adherence Status](CodeSystem-BeMedicationLineAdherenceStatus.md) |
| [9.29 Medication Line Registration Status](CodeSystem-BeMedicationLineRegistrationStatus.md) |
| [9.30 Medication Line Registration Status Value Set](ValueSet-BeMedicationLineRegistrationStatusVS.md) |
| [9.31 Medication origin Type](CodeSystem-BeMedicationLineOriginType.md) |
| [9.32 Medication origin type value set](ValueSet-BeMedicationLineOriginTypeVS.md) |
| [9.33 Medication preparation Type](CodeSystem-BeMedicationType.md) |
| [9.34 Medication preparation Type value set](ValueSet-BeMedicationTypeVS.md) |
| [9.35 Medication Prescription Status](ValueSet-BeMedicationPrescriptionStatusVS.md) |
| [9.36 Medication request reimbursement type](CodeSystem-BeMedicationRequestReimbursementType.md) |
| [9.37 Medication request reimbursement type ValueSet](ValueSet-BeMedicationRequestReimbursementTypeVS.md) |
| [9.38 Route of Administration ValueSet](ValueSet-BeRouteOfAdministrationVS.md) |
| [9.39 apotheek-onder-de-toren](Organization-apotheek-onder-de-toren.md) |
| [9.40 Example Dispense (minimal)](MedicationDispense-example-minimal-dispense.md) |
| [9.41 Example Dispense (simple)](MedicationDispense-medicationdispense-example-1.md) |
| [9.42 Example Dispense entry - Community Pharmacy dispense, from prescription, with contained org.](MedicationDispense-medicationdispense-example-2.md) |
| [9.43 Example Dispense from a hospital pharmacy](MedicationDispense-example-dispense-hospital.md) |
| [9.44 Medication Dispense example](MedicationDispense-example-dispense-communitypharmacy-1med.md) |

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  [next>](index.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

