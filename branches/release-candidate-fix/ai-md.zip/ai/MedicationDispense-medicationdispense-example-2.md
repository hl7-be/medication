# Example Dispense entry - Community Pharmacy dispense, from prescription, with contained org. - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Dispense entry - Community Pharmacy dispense, from prescription, with contained org.**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationDispense-medicationdispense-example-2.xml.md) 
*  [JSON](MedicationDispense-medicationdispense-example-2.json.md) 
*  [TTL](MedicationDispense-medicationdispense-example-2.ttl.md) 

## Example MedicationDispense: Example Dispense entry - Community Pharmacy dispense, from prescription, with contained org.

Language: nl-BE

Profile: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md)

**identifier**: dguid/a8ca980c-aa4f-44f3-8cf7-547e6ad3dba0

**status**: Completed

**medication**: Topazolam tab 50x 1,0mg

**subject**: Identifier: `https://www.ehealth.fgov.be/standards/fhir/NamingSystem/ssin`/64110219106

**context**: Identifier: sguid/b8ca980c-72aa-11e7-8cf7-a6006ad3dba0

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | [Apotheek onder de toren](#hcmedicationdispense-example-2/apotheek-onder-de-toren) |

**authorizingPrescription**: Prescription

**quantity**: 1(unit package from https://www.gfd-dpp.be/fhir/reference/packaging)(Details: packaging codepackage = 'package')

**whenHandedOver**: 2020-03-10

### DosageInstructions

| | |
| :--- | :--- |
| - | **Text** |
| * | 3 x per dag |

-------

> **Generated Narrative: Organization #apotheek-onder-de-toren**

Profile: [BeOrganization](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)

**identifier**:`https://www.ehealth.fgov.be/standards/fhir/NamingSystem/nihdi-organization`/27457532**type**:independent pharmacy

| | | |
| :--- | :--- | :--- |
|  [<prev](MedicationDispense-medicationdispense-example-1.ttl.md) | [top](#top) |  [next>](MedicationDispense-medicationdispense-example-2.xml.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

