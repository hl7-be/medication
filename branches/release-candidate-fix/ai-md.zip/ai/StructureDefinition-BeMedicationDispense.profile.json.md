# BeMedicationDispense - JSON Representation - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeMedicationDispense**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](StructureDefinition-BeMedicationDispense.md) 
*  [Detailed Descriptions](StructureDefinition-BeMedicationDispense-definitions.md) 
*  [Mappings](StructureDefinition-BeMedicationDispense-mappings.md) 
*  [Examples](StructureDefinition-BeMedicationDispense-examples.md) 
*  [XML](StructureDefinition-BeMedicationDispense.profile.xml.md) 
*  [JSON](#) 
*  [TTL](StructureDefinition-BeMedicationDispense.profile.ttl.md) 

## Resource Profile: BeMedicationDispense - JSON Profile

| | |
| :--- | :--- |
| Active as of 2025-10-08 | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 |

JSON representation of the BeMedicationDispense resource profile.

[Raw json](StructureDefinition-BeMedicationDispense.json) | [Download](StructureDefinition-BeMedicationDispense.json)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeMedicationDispense.profile.xml.md) | [top](#top) |  [next>](StructureDefinition-BeMedicationDispense.profile.ttl.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

