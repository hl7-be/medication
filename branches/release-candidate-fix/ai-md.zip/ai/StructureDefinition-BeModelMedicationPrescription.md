# Medication prescription (model) - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication prescription (model)**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeModelMedicationPrescription-definitions.md) 
*  [Mappings](StructureDefinition-BeModelMedicationPrescription-mappings.md) 
*  [XML](StructureDefinition-BeModelMedicationPrescription.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelMedicationPrescription.profile.json.md) 
*  [TTL](StructureDefinition-BeModelMedicationPrescription.profile.ttl.md) 

## Logical Model: Medication prescription (model) 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedicationPrescription | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BeModelMedicationPrescription |

 
Logical model for medication prescription (or some other form of order) 

### Relationship with other elements:

The Medication Prescription relates to the other data structures in the following way:

* A [Medication Prescription](StructureDefinition-BeModelMedicationPrescription.md) may be based on a [Medication Line](StructureDefinition-BeModelMedicationLine.md)
* A [Medication Prescription](StructureDefinition-BeModelMedicationPrescription.md) may also be initiating a [Medication Line](StructureDefinition-BeModelMedicationLine.md)
* [Medication Dispense](StructureDefinition-BeModelMedicationDispense.md) may be associated with a [Medication Prescription](StructureDefinition-BeModelMedicationPrescription.md)

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeModelMedicationPrescription)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(9 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Identifier(http://hl7.org/fhir/StructureDefinition/elementdefinition-identifier|5.2.0)](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-elementdefinition-identifier.html)
* [Medication Line (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedicationLine)](StructureDefinition-BeModelMedicationLine.md)
* [Medication (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedication)](StructureDefinition-BeModelMedication.md)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(9 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [Identifier(http://hl7.org/fhir/StructureDefinition/elementdefinition-identifier|5.2.0)](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-elementdefinition-identifier.html)
* [Medication Line (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedicationLine)](StructureDefinition-BeModelMedicationLine.md)
* [Medication (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedication)](StructureDefinition-BeModelMedication.md)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

 

Other representations of profile: [CSV](StructureDefinition-BeModelMedicationPrescription.csv), [Excel](StructureDefinition-BeModelMedicationPrescription.xlsx) 

### Notes:

Detailed diagram:

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelMedicationLine.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeModelMedicationPrescription-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

