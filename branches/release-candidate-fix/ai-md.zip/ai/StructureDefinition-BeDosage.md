# Medication Dosage - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication Dosage**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeDosage-definitions.md) 
*  [Mappings](StructureDefinition-BeDosage-mappings.md) 
*  [XML](StructureDefinition-BeDosage.profile.xml.md) 
*  [JSON](StructureDefinition-BeDosage.profile.json.md) 
*  [TTL](StructureDefinition-BeDosage.profile.ttl.md) 

## Data Type Profile: Medication Dosage 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeDosage | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BeDosage |

 
Specifications for a medication dosage for use in Belgian profiles. 

**Usages:**

* Use this DataType Profile: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md), [BeMedicationLine](StructureDefinition-BeMedicationLine.md) and [BeMedicationPrescription](StructureDefinition-BeMedicationPrescription.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeDosage)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Dosage](http://hl7.org/fhir/R4/datatypes.html#Dosage) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Dosage](http://hl7.org/fhir/R4/datatypes.html#Dosage) 

**Summary**

Must-Support: 6 elements

**Structures**

This structure refers to these other structures:

* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Dosage.doseAndRate.dose[x]

 **Differential View** 

This structure is derived from [Dosage](http://hl7.org/fhir/R4/datatypes.html#Dosage) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Dosage](http://hl7.org/fhir/R4/datatypes.html#Dosage) 

**Summary**

Must-Support: 6 elements

**Structures**

This structure refers to these other structures:

* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Dosage.doseAndRate.dose[x]

 

Other representations of profile: [CSV](StructureDefinition-BeDosage.csv), [Excel](StructureDefinition-BeDosage.xlsx), [Schematron](StructureDefinition-BeDosage.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeMedicationPrescription.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeDosage-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

