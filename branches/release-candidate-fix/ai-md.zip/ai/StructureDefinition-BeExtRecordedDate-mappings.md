# BeExtRecordedDate - Mappings - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeExtRecordedDate**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](StructureDefinition-BeExtRecordedDate.md) 
*  [Detailed Descriptions](StructureDefinition-BeExtRecordedDate-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-BeExtRecordedDate.profile.xml.md) 
*  [JSON](StructureDefinition-BeExtRecordedDate.profile.json.md) 
*  [TTL](StructureDefinition-BeExtRecordedDate.profile.ttl.md) 

## Extension: BeExtRecordedDate - Mappings

| |
| :--- |
| Active as of 2025-10-08 |

Mappings for the BeExtRecordedDate extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeExtRecordedDate-definitions.md) | [top](#top) |  [next>](StructureDefinition-BeExtRecordedDate-testing.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

