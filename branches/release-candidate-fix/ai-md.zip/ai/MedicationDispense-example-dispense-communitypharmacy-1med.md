# Medication Dispense example - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication Dispense example**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationDispense-example-dispense-communitypharmacy-1med.xml.md) 
*  [JSON](MedicationDispense-example-dispense-communitypharmacy-1med.json.md) 
*  [TTL](MedicationDispense-example-dispense-communitypharmacy-1med.ttl.md) 

## Example MedicationDispense: Medication Dispense example

Language: fr-BE

Profile: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md)

**identifier**: dguid/a8c45fdc-72aa-11e7-8cf7-a6007ad37dc0

**status**: Completed

**medication**: Topazolam tab 50x 1,0mg

**subject**: Identifier: `https://www.ehealth.fgov.be/standards/fhir/NamingSystem/ssin`/64110219106

**context**: Identifier: sguid/b8ca980c-72aa-11e7-8cf7-a6006ad3dba0

> **performer****actor**: Jan Janssen (Identifier:`https://www.ehealth.fgov.be/standards/fhir/NamingSystem/nihdi-practitioner`/6547432)

> **performer****actor**: Apotheek onder de toren (Identifier:`https://www.ehealth.fgov.be/standards/fhir/NamingSystem/nihdi-organization`/27457532)

**authorizingPrescription**: Prescription 2014fd (Identifier: [BeNSPrescriptions](NamingSystem-be-ns-prescription-ids.md)/2d8dab92-5c38-4380-96a9-e461be2014fd)

**quantity**: 1(unit package from https://www.gfd-dpp.be/fhir/reference/packaging)(Details: packaging codepackage = 'package')

**whenHandedOver**: 2020-03-10

### DosageInstructions

| | |
| :--- | :--- |
| - | **Text** |
| * | 3 x par jour |

| | | |
| :--- | :--- | :--- |
|  [<prev](MedicationDispense-example-dispense-hospital.ttl.md) | [top](#top) |  [next>](MedicationDispense-example-dispense-communitypharmacy-1med.xml.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

