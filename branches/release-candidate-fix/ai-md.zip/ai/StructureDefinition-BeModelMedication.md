# Medication (model) - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication (model)**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeModelMedication-definitions.md) 
*  [Mappings](StructureDefinition-BeModelMedication-mappings.md) 
*  [XML](StructureDefinition-BeModelMedication.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelMedication.profile.json.md) 
*  [TTL](StructureDefinition-BeModelMedication.profile.ttl.md) 

## Logical Model: Medication (model) 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedication | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BeModelMedication |

 
Logical data model for medication. 

### Relationship with other elements:

The Medication model relates to the other data structures in the following way:

This model is just a placeholder and has not been implemented as a FHIR resource. Implementers are expected to use the Medication resource which will be profiled later.

* [Medication Line](StructureDefinition-BeModelMedicationDispense.md) may refer to a [Medication Dispense](StructureDefinition-BeModelMedicationDispense.md) that occurs in the treatment.
* [Medication Dispense](StructureDefinition-BeModelMedicationDispense.md) may be the trigger for creating or updating a [Medication Line](StructureDefinition-BeModelMedicationLine.md).

**Usages:**

* Refer to this Logical Model: [Medication Line (model)](StructureDefinition-BeModelMedicationLine.md) and [Medication prescription (model)](StructureDefinition-BeModelMedicationPrescription.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeModelMedication)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Constraints

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

 **Key Elements View** 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(4 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [SimpleQuantity(http://hl7.org/fhir/StructureDefinition/SimpleQuantity)](http://hl7.org/fhir/R4/datatypes.html#SimpleQuantity)

 

Other representations of profile: [CSV](StructureDefinition-BeModelMedication.csv), [Excel](StructureDefinition-BeModelMedication.xlsx) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelDosagingInformation.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeModelMedication-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

