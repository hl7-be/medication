# Adherence Status Reason ValueSet - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Adherence Status Reason ValueSet**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](#) 
*  [XML](ValueSet-BeMedicationLineAdherenceStatusReasonVS.xml.md) 
*  [JSON](ValueSet-BeMedicationLineAdherenceStatusReasonVS.json.md) 
*  [TTL](ValueSet-BeMedicationLineAdherenceStatusReasonVS.ttl.md) 

## ValueSet: Adherence Status Reason ValueSet (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/terminology/ValueSet/BeMedicationLineAdherenceStatusReasonVS | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BeMedicationLineAdherenceStatusReasonVS |

 
ValueSet containing reasons for non-adherence to a treatment or intervention. 

 **References** 

* [BeMedicationLine](StructureDefinition-BeMedicationLine.md)
* [Medication Line (model)](StructureDefinition-BeModelMedicationLine.md)

### Logical Definition (CLD)

* Include all codes defined in [`https://www.ehealth.fgov.be/standards/fhir/terminology/CodeSystem/BeMedicationLineAdherenceStatusReason`](CodeSystem-BeMedicationLineAdherenceStatusReason.md) version 📦1.1.0

 

### Expansion

Expansion performed internally based on [codesystem Adherence Status Reason v1.1.0 (CodeSystem)](CodeSystem-BeMedicationLineAdherenceStatusReason.md)

This value set contains 7 concepts

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-BeMedicationLineAdherenceStatusReason.ttl.md) | [top](#top) |  [next>](ValueSet-BeMedicationLineAdherenceStatusReasonVS-testing.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

