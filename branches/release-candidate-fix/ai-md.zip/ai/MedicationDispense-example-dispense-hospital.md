# Example Dispense from a hospital pharmacy - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Dispense from a hospital pharmacy**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationDispense-example-dispense-hospital.xml.md) 
*  [JSON](MedicationDispense-example-dispense-hospital.json.md) 
*  [TTL](MedicationDispense-example-dispense-hospital.ttl.md) 

## Example MedicationDispense: Example Dispense from a hospital pharmacy

version: 1; Language: nl-BE

Profile: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md)

**identifier**: dguid/1000321345

**status**: Completed

**medication**: 2055218

**subject**: Identifier: `https://www.ehealth.fgov.be/standards/fhir/NamingSystem/ssin`/64110219106

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | Identifier:`https://www.ehealth.fgov.be/standards/fhir/NamingSystem/nihdi-organization`/123123123 |

**authorizingPrescription**: Prescription (Identifier: [BeNSPrescriptions](NamingSystem-be-ns-prescription-ids.md)/BEP1TSRY1XGE)

**quantity**: 1 package(Details: UCUM code1 = '1')

**whenHandedOver**: 2020-09-21 13:00:00+0200

### DosageInstructions

| | | |
| :--- | :--- | :--- |
| - | **Text** | **Timing** |
| * | 3 x a day | 3 per 1 day |

| | | |
| :--- | :--- | :--- |
|  [<prev](MedicationDispense-medicationdispense-example-2.ttl.md) | [top](#top) |  [next>](MedicationDispense-example-dispense-hospital.xml.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

