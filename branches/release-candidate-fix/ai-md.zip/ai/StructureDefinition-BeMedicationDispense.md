# BeMedicationDispense - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeMedicationDispense**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeMedicationDispense-definitions.md) 
*  [Mappings](StructureDefinition-BeMedicationDispense-mappings.md) 
*  [Examples](StructureDefinition-BeMedicationDispense-examples.md) 
*  [XML](StructureDefinition-BeMedicationDispense.profile.xml.md) 
*  [JSON](StructureDefinition-BeMedicationDispense.profile.json.md) 
*  [TTL](StructureDefinition-BeMedicationDispense.profile.ttl.md) 

## Resource Profile: BeMedicationDispense 

| | | |
| :--- | :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeMedicationDispense | *Version*:1.1.0 | |
| Active as of 2025-10-08 | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 1 | *Computable Name*:BeMedicationDispense |

 
Defines constraints and extensions on the Medication Dispense resource for a record of a dispensation in Belgium. 

**Usages:**

* Examples for this Profile: [MedicationDispense/example-dispense-communitypharmacy-1med](MedicationDispense-example-dispense-communitypharmacy-1med.md), [MedicationDispense/example-dispense-hospital](MedicationDispense-example-dispense-hospital.md), [MedicationDispense/example-minimal-dispense](MedicationDispense-example-minimal-dispense.md), [MedicationDispense/medicationdispense-example-1](MedicationDispense-medicationdispense-example-1.md) and [MedicationDispense/medicationdispense-example-2](MedicationDispense-medicationdispense-example-2.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeMedicationDispense)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R4/medicationdispense.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R4/medicationdispense.html) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 18 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [Medication Dosage(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeDosage)](StructureDefinition-BeDosage.md)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.recorded](http://hl7.org/fhir/R4/medicationdispense-definitions.html#MedicationDispense.recorded)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BasedOnMedicationLine](StructureDefinition-BasedOnMedicationLine.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtOffLabel](StructureDefinition-BeExtOffLabel.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationDispense.identifier
* The element 1 is sliced based on the value of MedicationDispense.medication[x]

**[Maturity](http://hl7.org/fhir/versions.html#maturity)**: 1

 **Differential View** 

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R4/medicationdispense.html) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationDispense](http://hl7.org/fhir/R4/medicationdispense.html) 

**Summary**

Mandatory: 3 elements(1 nested mandatory element)
 Must-Support: 18 elements
 Fixed: 1 element

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [Medication Dosage(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeDosage)](StructureDefinition-BeDosage.md)

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationDispense.recorded](http://hl7.org/fhir/R4/medicationdispense-definitions.html#MedicationDispense.recorded)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BasedOnMedicationLine](StructureDefinition-BasedOnMedicationLine.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtOffLabel](StructureDefinition-BeExtOffLabel.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationDispense.identifier
* The element 1 is sliced based on the value of MedicationDispense.medication[x]

**[Maturity](http://hl7.org/fhir/versions.html#maturity)**: 1

 

Other representations of profile: [CSV](StructureDefinition-BeMedicationDispense.csv), [Excel](StructureDefinition-BeMedicationDispense.xlsx), [Schematron](StructureDefinition-BeMedicationDispense.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelMedicationPrescription.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeMedicationDispense-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

