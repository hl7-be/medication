# BeMedicationLine - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BeMedicationLine**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeMedicationLine-definitions.md) 
*  [Mappings](StructureDefinition-BeMedicationLine-mappings.md) 
*  [XML](StructureDefinition-BeMedicationLine.profile.xml.md) 
*  [JSON](StructureDefinition-BeMedicationLine.profile.json.md) 
*  [TTL](StructureDefinition-BeMedicationLine.profile.ttl.md) 

## Resource Profile: BeMedicationLine 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeMedicationLine | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:BeMedicationLine |

 
Medication Line profile - contains the overview information for a single medication item 

**Usages:**

* Refer to this Profile: [BasedOnMedicationLine](StructureDefinition-BasedOnMedicationLine.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeMedicationLine)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [MedicationStatement](http://hl7.org/fhir/R4/medicationstatement.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationStatement](http://hl7.org/fhir/R4/medicationstatement.html) 

**Summary**

Mandatory: 11 elements(1 nested mandatory element)
 Must-Support: 27 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [Medication Dosage(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeDosage)](StructureDefinition-BeDosage.md)

**Extensions**

This structure refers to these extensions:

* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtRecordedDate](StructureDefinition-BeExtRecordedDate.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtRecorder](StructureDefinition-BeExtRecorder.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeMedicationExposureCategory](StructureDefinition-BeMedicationExposureCategory.md)
* [http://hl7.org/fhir/StructureDefinition/artifact-version|5.2.0](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-artifact-version.html)
* [http://hl7.org/fhir/StructureDefinition/artifact-date|5.2.0](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-artifact-date.html)
* [http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationStatement.adherence.code](http://hl7.org/fhir/R4/medicationstatement-definitions.html#MedicationStatement.adherence.code)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtMedicationLineRegistrationStatus](StructureDefinition-BeExtMedicationLineRegistrationStatus.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtOffLabel](StructureDefinition-BeExtOffLabel.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtMedicationType](StructureDefinition-BeExtMedicationType.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationStatement.identifier
* The element 1 is sliced based on the value of MedicationStatement.effective[x]

 **Differential View** 

This structure is derived from [MedicationStatement](http://hl7.org/fhir/R4/medicationstatement.html) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [MedicationStatement](http://hl7.org/fhir/R4/medicationstatement.html) 

**Summary**

Mandatory: 11 elements(1 nested mandatory element)
 Must-Support: 27 elements

**Structures**

This structure refers to these other structures:

* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePractitionerRole(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitionerrole)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitionerrole.html)
* [BeOrganization(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-organization)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-organization.html)
* [Medication Dosage(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeDosage)](StructureDefinition-BeDosage.md)

**Extensions**

This structure refers to these extensions:

* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtRecordedDate](StructureDefinition-BeExtRecordedDate.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtRecorder](StructureDefinition-BeExtRecorder.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeMedicationExposureCategory](StructureDefinition-BeMedicationExposureCategory.md)
* [http://hl7.org/fhir/StructureDefinition/artifact-version|5.2.0](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-artifact-version.html)
* [http://hl7.org/fhir/StructureDefinition/artifact-date|5.2.0](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-artifact-date.html)
* [http://hl7.org/fhir/5.0/StructureDefinition/extension-MedicationStatement.adherence.code](http://hl7.org/fhir/R4/medicationstatement-definitions.html#MedicationStatement.adherence.code)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtMedicationLineRegistrationStatus](StructureDefinition-BeExtMedicationLineRegistrationStatus.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtOffLabel](StructureDefinition-BeExtOffLabel.md)
* [https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeExtMedicationType](StructureDefinition-BeExtMedicationType.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of MedicationStatement.identifier
* The element 1 is sliced based on the value of MedicationStatement.effective[x]

 

Other representations of profile: [CSV](StructureDefinition-BeMedicationLine.csv), [Excel](StructureDefinition-BeMedicationLine.xlsx), [Schematron](StructureDefinition-BeMedicationLine.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeMedicationDispense.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeMedicationLine-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

