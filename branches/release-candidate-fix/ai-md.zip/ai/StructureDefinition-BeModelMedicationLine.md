# Medication Line (model) - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medication Line (model)**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-BeModelMedicationLine-definitions.md) 
*  [Mappings](StructureDefinition-BeModelMedicationLine-mappings.md) 
*  [XML](StructureDefinition-BeModelMedicationLine.profile.xml.md) 
*  [JSON](StructureDefinition-BeModelMedicationLine.profile.json.md) 
*  [TTL](StructureDefinition-BeModelMedicationLine.profile.ttl.md) 

## Logical Model: Medication Line (model) 

| | |
| :--- | :--- |
| *Official URL*:https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedicationLine | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:MedicationLine |

 
Logical data model for medication line. 

### Relationship with other elements:

The Medication Line relates to the other data structures in the following way:

* [Medication Line](StructureDefinition-BeModelMedicationDispense.md) may refer to a [Medication Dispense](StructureDefinition-BeModelMedicationDispense.md) that occurs in the treatment.
* [Medication Dispense](StructureDefinition-BeModelMedicationDispense.md) may be the trigger for creating or updating a [Medication Line](StructureDefinition-BeModelMedicationLine.md).

**Usages:**

* Refer to this Logical Model: [Medication Dispense (model)](StructureDefinition-BeModelMedicationDispense.md) and [Medication prescription (model)](StructureDefinition-BeModelMedicationPrescription.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/hl7.fhir.be.medication|current/StructureDefinition/BeModelMedicationLine)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(11 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [Medication (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedication)](StructureDefinition-BeModelMedication.md)

 **Differential View** 

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Base](http://build.fhir.org/types.html#Base) 

**Summary**

Mandatory: 0 element(11 nested mandatory elements)

**Structures**

This structure refers to these other structures:

* [BePractitioner(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-practitioner)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-practitioner.html)
* [BePatient(https://www.ehealth.fgov.be/standards/fhir/core/StructureDefinition/be-patient)](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/StructureDefinition-be-patient.html)
* [Medication (model)(https://www.ehealth.fgov.be/standards/fhir/medication/StructureDefinition/BeModelMedication)](StructureDefinition-BeModelMedication.md)

 

Other representations of profile: [CSV](StructureDefinition-BeModelMedicationLine.csv), [Excel](StructureDefinition-BeModelMedicationLine.xlsx) 

### Notes:

Detailed diagram:

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-BeModelMedicationDispense.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-BeModelMedicationLine-definitions.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

