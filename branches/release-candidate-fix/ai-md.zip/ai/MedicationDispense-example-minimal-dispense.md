# Example Dispense (minimal) - Medication v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Dispense (minimal)**

Medication, published by eHealth Platform. This guide is not an authorized publication; it is the continuous build for version 1.1.0 built by the FHIR (HL7® FHIR® Standard) CI Build. This version is based on the current content of [https://github.com/hl7-be/medication/tree/312/merge](https://github.com/hl7-be/medication/tree/312/merge) and changes regularly. See the [Directory of published versions](https://www.ehealth.fgov.be/standards/fhir/medication/history.html)

*  [Narrative Content](#) 
*  [XML](MedicationDispense-example-minimal-dispense.xml.md) 
*  [JSON](MedicationDispense-example-minimal-dispense.json.md) 
*  [TTL](MedicationDispense-example-minimal-dispense.ttl.md) 

## Example MedicationDispense: Example Dispense (minimal)

Profile: [BeMedicationDispense](StructureDefinition-BeMedicationDispense.md)

**status**: Completed

**medication**: Topazolam tab 50x 1,0mg

**subject**: Identifier: [BeSSINNamingSystem](https://www.ehealth.fgov.be/standards/fhir/core/2.1.2/NamingSystem-be-ssin.html)/64110219106

### Performers

| | |
| :--- | :--- |
| - | **Actor** |
| * | Jan Janssen (Identifier:`https://www.ehealth.fgov.be/standards/fhir/NamingSystem/nihdi-practitioner`/6547432) |

**whenHandedOver**: 2020-03-10

| | | |
| :--- | :--- | :--- |
|  [<prev](Organization-apotheek-onder-de-toren.ttl.md) | [top](#top) |  [next>](MedicationDispense-example-minimal-dispense.xml.md) |

 IG © 2021+ [eHealth Platform](https://www.ehealth.fgov.be/standards/fhir). Package hl7.fhir.be.medication#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
 Links:[Table of Contents](toc.md)|[QA Report](qa.md)![](assets/images/logo-be.png)![](assets/images/logo-ehealth.png) 

